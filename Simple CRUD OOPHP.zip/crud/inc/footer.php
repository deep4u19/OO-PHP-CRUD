<div class="footer">
		<p>This is footer</p>
	</div>
</body>
</html>