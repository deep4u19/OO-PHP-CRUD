<?php 
include 'inc/header.php';
include 'config.php';
include 'database.php';

?>
<?php  
if(isset($_GET['msg'])){?>

	<p><?php echo "<span style='color: red;'>".($_GET['msg'])."</span>";?></p>
<?php } ?>

<?php 

$db=new Database();
$query='SELECT * FROM users';
$read=$db->select($query);

?>







<div class="content" >
	<table class="tblone">
	<tr>
		<th width="10%">Serial</th>
		<th width="25%">Name</th>
		<th width="25%">Email</th>
		<th width="25%">Age</th>
		<th width="15%">Action</th>
	</tr>
<?php  if($read)  {?>
<?php $i=1; while($row=$read->fetch_assoc()){ ?>
	<tr>
		<td><?php echo $i++ ?></td>
		<td><?php echo $row['name'] ?></td>
		<td><?php echo $row['email'] ?></td>
		<td><?php echo $row['age'] ?></td>
		<td><a href="update.php?id=<?php echo urlencode($row['id']); ?>"><button class="btn btn-success">Edit</button></a></td>
	</tr>
<?php }?>
<?php } else{  ?>
<p>Database not Available</p>
<?php } ?>

</table>
<div style="height: 57px;">
<a style="color: #fff;" href="create.php"><button class="btn btn-primary center-block" style="padding: 10px 30px;">Create</button></a>
</div>	
</div>







<?php include 'inc/footer.php'; ?>

	

	