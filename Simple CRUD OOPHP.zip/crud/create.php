<?php 
include 'inc/header.php';
include 'config.php';
include 'database.php';

?>

<?php  
if(isset($_GET['msg'])){?>

	<p><?php echo "<span style='color: red;'>".($_GET['msg'])."</span>";?></p>
<?php } ?>

<?php 

$db=new Database();
if(isset($_POST['submit'])){
	$name=mysqli_real_escape_string($db->link,$_POST['name']);
	$email=mysqli_real_escape_string($db->link,$_POST['email']);
	$age=mysqli_real_escape_string($db->link,$_POST['age']);

	if($name==""|| $email=="" || $age==""){
		$error="No field can be empty";
	}else{
		$query="INSERT INTO users(name,email,age) VALUES('$name','$email','$age')";
		$create =$db->insert($query);
	}
}

?>







<div class="content" >

<?php  
if(isset($error)){
	echo "<span style='color: green;'>".$error."</span>";
}
?>

<form action="create.php" method="post">
<table class="tbl-create" style="width: 75%;margin-left: 15px;">
	<tr>
		<td width="10%">Name </td>

		<td>
		<input type="text" class="form-control" id="usr" name="name" placeholder="Enter Your Name" >
		</td>
	</tr>


	<tr>
		<td>Email</td>
		<td>
			<input class="form-control" id="usr" type="email" name="email" placeholder="Enter Your Email">
		</td>
	</tr>
	<tr>
		<td>Age </td>
		<td>
			<input type="text" class="form-control" id="usr" name="age" placeholder="Enter Your Age">
		</td>
	</tr>
	<tr>
		<td></td>
		<td>
			<input class="btn btn-success" type="submit" name="submit" value="Submit">
			<input class="btn btn-warning" type="reset" value="Cancel">
		</td>
	</tr>
</table>
</form>
<div style="margin-top: 18px; margin-left: 75px;margin-bottom: 0px;height: 40px;">
	<a href="index.php" style="background: #b2e9fb;padding: 10px;color: #333;border-radius: 4px;">Go Back</a>
</div>		
</div>







<?php include 'inc/footer.php'; ?>

	

	