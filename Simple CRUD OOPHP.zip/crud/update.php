<?php 
include 'inc/header.php';
include 'config.php';
include 'database.php';

?>

<?php 

$db=new Database();
$id=$_GET['id'];
$query="SELECT * FROM users WHERE id=$id";
$getData=$db->select($query)->fetch_assoc();


if(isset($_POST['submit'])){
	$name=mysqli_real_escape_string($db->link,$_POST['name']);
	$email=mysqli_real_escape_string($db->link,$_POST['email']);
	$age=mysqli_real_escape_string($db->link,$_POST['age']);

	if( $name ==''|| $email=='' || $age==''){
		$error="No field can be empty";
	}else{
		$query="UPDATE users
			SET name='$name',
				email='$email',
				age  ='$age'
				WHERE id=$id		
				";
		$update =$db->update($query);
	}
}

?>


<?php if(isset($_POST['delete'])){
	$query="DELETE FROM users WHERE id=$id ";
	$deleteData=$db->delete($query);
} ?>


<div class="content" >

<?php  
if(isset($error)){
	echo "<span style='color: green;'>".$error."</span>";
}
?>

<form action="update.php?id=<?php echo $id;?>" method="post">
<table class="tbl-create" style="width: 75%;margin-left: 15px;">
	<tr>
		<td width="10%">Name </td>

		<td>
		<input value="<?php echo($getData['name'])?>" type="text" class="form-control" id="usr" name="name" placeholder="Enter Your Name" >
		</td>
	</tr>


	<tr>
		<td>Email</td>
		<td>
			<input value=" <?php echo($getData['email']) ?> " class="form-control" id="usr" type="email" name="email" placeholder="Enter Your Email">
		</td>
	</tr>
	<tr>
		<td>Age </td>
		<td>
			<input value="<?php echo($getData['age'])?>" type="text" class="form-control" id="usr" name="age" placeholder="Enter Your Age">
		</td>
	</tr>
	<tr>
		<td></td>
		<td>
			<input class="btn btn-success" type="submit" name="submit" value="Submit">
			
			<input class="btn btn-primary" type="submit" name="delete" value="Delete" onclick="return confirm('Are you sure to delete??')">
		</td>
	</tr>
</table>






</form>
<div style="margin-top: 18px; margin-left: 75px;margin-bottom: 0px;height: 40px;">
	<a href="index.php" style="background: #b2e9fb;padding: 10px;color: #333;border-radius: 4px;">Go Back</a>
</div>		

</div>


<?php include 'inc/footer.php'; ?>

	

	