<!DOCTYPE html>
<html>
<head>
	<title>CRUD</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body class="wrap">
	<div class="header">
		<a href="index.php"><h3>Simple Crud</h3></a>
	</div>